import {
  boolean,
  integer,
  pgTable,
  primaryKey,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const chatUsersTable = pgTable("chat_users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  username: text("username").notNull().unique(),
  initials: text("initials").notNull(),
  avatarUrl: text("avatar_url"),
  status: text("status").notNull().default("offline"),
  lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
  bio: text("bio"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const conversationsTable = pgTable("conversations", {
  id: uuid("id").defaultRandom().primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const conversationMembersTable = pgTable(
  "conversation_members",
  {
    conversationId: uuid("conversation_id")
      .notNull()
      .references(() => conversationsTable.id, { onDelete: "cascade" }),
    userId: text("user_id")
      .notNull()
      .references(() => chatUsersTable.id, { onDelete: "cascade" }),
    unreadCount: integer("unread_count").notNull().default(0),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.conversationId, table.userId] }),
  }),
);

export const messagesTable = pgTable("messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id")
    .notNull()
    .references(() => conversationsTable.id, { onDelete: "cascade" }),
  senderId: text("sender_id")
    .notNull()
    .references(() => chatUsersTable.id, { onDelete: "cascade" }),
  body: text("body"),
  type: text("type").notNull().default("text"),
  attachmentUrl: text("attachment_url"),
  attachmentName: text("attachment_name"),
  durationSeconds: integer("duration_seconds"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  readAt: timestamp("read_at", { withTimezone: true }),
});

export const notificationsTable = pgTable("notifications", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => chatUsersTable.id, { onDelete: "cascade" }),
  kind: text("kind").notNull().default("message"),
  title: text("title").notNull(),
  body: text("body").notNull(),
  conversationId: uuid("conversation_id").references(() => conversationsTable.id, {
    onDelete: "cascade",
  }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  read: boolean("read").notNull().default(false),
});

export const insertChatUserSchema = createInsertSchema(chatUsersTable);
export const insertMessageSchema = createInsertSchema(messagesTable);
export const insertNotificationSchema = createInsertSchema(notificationsTable);

export type ChatUser = typeof chatUsersTable.$inferSelect;
export type Conversation = typeof conversationsTable.$inferSelect;
export type Message = typeof messagesTable.$inferSelect;
export type Notification = typeof notificationsTable.$inferSelect;
export type InsertChatUser = z.infer<typeof insertChatUserSchema>;