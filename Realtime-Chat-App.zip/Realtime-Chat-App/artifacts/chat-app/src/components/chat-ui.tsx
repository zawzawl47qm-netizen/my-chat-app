import { Bell, FileAudio, FileImage, FileVideo, Mic, Paperclip, Send, Settings2, Sparkles, X } from "lucide-react";
import { Link } from "wouter";
import type { ChatUser, Conversation, Message, Notification } from "@workspace/api-client-react";
import { useRef, useState, type ChangeEvent, type ReactNode } from "react";

export const avatarColors = [
  "bg-[#e8b17a] text-[#56301e]", "bg-[#c7d9a8] text-[#29412a]", "bg-[#cbb7d9] text-[#432950]",
  "bg-[#a9cee0] text-[#194454]", "bg-[#f0c4b5] text-[#6b3028]",
];

export function initialsFor(user?: Pick<ChatUser, "initials" | "name"> | null) {
  return user?.initials || user?.name?.split(" ").map((part) => part[0]).join("").slice(0, 2).toUpperCase() || "??";
}

export function Avatar({ user, size = "md", online = false }: { user?: Pick<ChatUser, "initials" | "name" | "avatarUrl" | "status"> | null; size?: "sm" | "md" | "lg"; online?: boolean }) {
  const sizeClass = size === "sm" ? "h-8 w-8 text-[10px]" : size === "lg" ? "h-14 w-14 text-sm" : "h-11 w-11 text-xs";
  const color = avatarColors[(user?.name?.length || 0) % avatarColors.length];
  return (
    <span className={`relative inline-flex shrink-0 items-center justify-center overflow-visible rounded-[14px] font-display font-bold ${sizeClass} ${color}`} data-testid={`avatar-${user?.name || "unknown"}`}>
      {user?.avatarUrl ? <img src={user.avatarUrl} alt={`${user.name} avatar`} className="h-full w-full rounded-[14px] object-cover" /> : initialsFor(user)}
      {(online || user?.status === "online") && <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-card bg-[#67ae74]" />}
    </span>
  );
}

export function StatusDot({ status }: { status: ChatUser["status"] }) {
  return <span className={`inline-block h-2 w-2 rounded-full ${status === "online" ? "bg-[#67ae74]" : status === "away" ? "bg-[#e6a84d]" : "bg-[#a89e94]"}`} />;
}

export function PresenceLabel({ user }: { user: ChatUser }) {
  const text = user.status === "online" ? "Active now" : user.status === "away" ? "Away for a little while" : `Last seen ${formatRelative(user.lastSeen)}`;
  return <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground"><StatusDot status={user.status} />{text}</span>;
}

export function formatRelative(date: string) {
  const diff = Math.max(0, Date.now() - new Date(date).getTime());
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export function formatTime(date: string) {
  return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(new Date(date));
}

export function Logo({ inverse = false }: { inverse?: boolean }) {
  return <Link href="/" className="group inline-flex items-center gap-2.5" data-testid="link-logo">
    <span className={`relative flex h-9 w-9 rotate-[-6deg] items-center justify-center rounded-[12px] ${inverse ? "bg-[#f4bd72]" : "bg-primary"} transition-transform duration-300 group-hover:rotate-3`}>
      <span className={`h-3.5 w-3.5 rounded-full border-[3px] ${inverse ? "border-[#56301e]" : "border-[#f8eedc]"}`} />
      <span className={`absolute bottom-1.5 right-1.5 h-1.5 w-1.5 rounded-full ${inverse ? "bg-[#56301e]" : "bg-[#f4bd72]"}`} />
    </span>
    <span className={`font-display text-[1.1rem] font-bold tracking-[-.04em] ${inverse ? "text-[#fff4e2]" : "text-primary"}`}>Chat App</span>
  </Link>;
}

export function Topbar({ title, notifications = 0, onBell, onSettings, mobileMenu }: { title?: string; notifications?: number; onBell?: () => void; onSettings?: () => void; mobileMenu?: ReactNode }) {
  return <header className="flex h-[76px] items-center justify-between border-b border-border/70 px-5 md:px-8">
    <div className="flex items-center gap-3">{mobileMenu}<span className="font-display text-xl font-bold tracking-[-.03em]">{title || "Good to see you"}</span></div>
    <div className="flex items-center gap-2">
      <button onClick={onBell} className="relative grid h-10 w-10 place-items-center rounded-xl text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground" data-testid="button-notifications" aria-label="Notifications">
        <Bell className="h-[18px] w-[18px]" strokeWidth={1.8} />{notifications > 0 && <span className="absolute right-2 top-1.5 h-1.5 w-1.5 rounded-full bg-[#d55d4d]" />}
      </button>
      <button onClick={onSettings} className="grid h-10 w-10 place-items-center rounded-xl text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground" data-testid="button-settings" aria-label="Settings"><Settings2 className="h-[18px] w-[18px]" strokeWidth={1.8} /></button>
    </div>
  </header>;
}

export function SideNav({ currentUser, active = "inbox", notifications = 0, onClose }: { currentUser?: ChatUser | null; active?: string; notifications?: number; onClose?: () => void }) {
  const items = [{ key: "inbox", href: "/chat", label: "Inbox", icon: Sparkles }, { key: "notifications", href: "/chat?notifications=1", label: "Notifications", icon: Bell }];
  return <aside className="flex h-full w-[272px] shrink-0 flex-col bg-sidebar px-5 py-6 text-sidebar-foreground">
    <div className="mb-12 flex items-center justify-between"><Logo inverse />{onClose && <button onClick={onClose} className="rounded-lg p-2 hover:bg-sidebar-accent" data-testid="button-close-menu"><X className="h-4 w-4" /></button>}</div>
    <div className="mb-8 flex items-center gap-3 rounded-2xl bg-sidebar-accent/70 p-3">
      <Avatar user={currentUser} size="sm" online />
      <div className="min-w-0"><p className="truncate text-sm font-semibold">{currentUser?.name || "Your profile"}</p><p className="truncate font-mono-app text-[10px] text-sidebar-foreground/60">@{currentUser?.username || "you"}</p></div>
      <span className="ml-auto h-2 w-2 rounded-full bg-[#7bbb7d]" />
    </div>
    <p className="mb-3 px-3 font-mono-app text-[10px] uppercase tracking-[.18em] text-sidebar-foreground/45">Your space</p>
    <nav className="space-y-1">
      {items.map(({ key, href, label, icon: Icon }) => <Link key={key} href={href} onClick={onClose} className={`group flex items-center gap-3 rounded-xl px-3 py-3 text-sm transition-all ${active === key ? "bg-sidebar-primary font-bold text-sidebar-primary-foreground" : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"}`} data-testid={`link-${key}`}><Icon className="h-[17px] w-[17px]" strokeWidth={active === key ? 2.3 : 1.7} /><span>{label}</span>{key === "notifications" && notifications > 0 && <span className="ml-auto rounded-full bg-[#d76d59] px-2 py-0.5 font-mono-app text-[10px] font-medium text-[#fff4e2]">{notifications}</span>}</Link>)}
    </nav>
    <div className="mt-auto space-y-1"><Link href="/settings" onClick={onClose} className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-sidebar-foreground/70 transition-all hover:bg-sidebar-accent hover:text-sidebar-foreground" data-testid="link-settings"><Settings2 className="h-[17px] w-[17px]" strokeWidth={1.7} />Preferences</Link><div className="mt-6 border-t border-sidebar-border pt-5"><p className="px-3 text-xs leading-5 text-sidebar-foreground/45">A quieter way to stay close.</p></div></div>
  </aside>;
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return <div className="flex min-h-[320px] flex-col items-center justify-center rounded-3xl border border-dashed border-border bg-card/40 p-8 text-center"><div className="mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-accent/45 text-primary"><Sparkles className="h-6 w-6" strokeWidth={1.6} /></div><h3 className="font-display text-xl font-bold">{title}</h3><p className="mt-2 max-w-xs text-sm leading-6 text-muted-foreground">{body}</p>{action}</div>;
}

export function ConversationRow({ conversation, active, onClick }: { conversation: Conversation; active?: boolean; onClick?: () => void }) {
  const participant = conversation.participant;
  return <button onClick={onClick} className={`group flex w-full items-center gap-3 rounded-2xl p-3 text-left transition-all ${active ? "bg-secondary shadow-[inset_3px_0_0_hsl(var(--primary))]" : "hover:bg-secondary/75"}`} data-testid={`button-conversation-${conversation.id}`}>
    <Avatar user={participant} online={participant.status === "online"} /><span className="min-w-0 flex-1"><span className="flex items-center justify-between gap-2"><span className="truncate text-sm font-semibold">{participant.name}</span><span className="font-mono-app text-[10px] text-muted-foreground">{formatRelative(conversation.updatedAt)}</span></span><span className="mt-1 flex items-center justify-between gap-2"><span className="flex min-w-0 items-center gap-1 text-xs text-muted-foreground"><MessageTypeIcon type={conversation.lastMessageType} /><span className="truncate">{conversation.lastMessage || "Start a conversation"}</span></span>{conversation.unreadCount > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1.5 font-mono-app text-[10px] text-primary-foreground">{conversation.unreadCount}</span>}</span></span>
  </button>;
}

function MessageTypeIcon({ type }: { type?: Conversation["lastMessageType"] }) {
  if (type === "image") return <FileImage className="h-3 w-3 shrink-0" />;
  if (type === "video") return <FileVideo className="h-3 w-3 shrink-0" />;
  if (type === "audio") return <FileAudio className="h-3 w-3 shrink-0" />;
  return null;
}

export function MessageBubble({ message }: { message: Message }) {
  const attachment = message.attachmentUrl ? `${message.type} · ${message.attachmentName || "attachment"}` : null;
  return <div className={`group flex items-end gap-2 ${message.isMine ? "justify-end" : "justify-start"}`} data-testid={`message-${message.id}`}>
    {!message.isMine && <Avatar user={{ name: message.senderName || "Friend", initials: initialsFor({ name: message.senderName || "Friend", initials: "" }), status: "offline" }} size="sm" />}
    <div className={`max-w-[min(76%,540px)] ${message.isMine ? "items-end" : "items-start"} flex flex-col`}>
      <div className={`rounded-[20px] px-4 py-3 text-sm leading-6 ${message.isMine ? "rounded-br-md bg-primary text-primary-foreground" : "rounded-bl-md bg-card shadow-[0_4px_18px_hsl(22_49%_19%_/_0.05)] ring-1 ring-border/80"}`}>
        {message.body && <p>{message.body}</p>}
        {message.attachmentUrl && <a href={message.attachmentUrl} target="_blank" rel="noreferrer" className="mt-2 flex items-center gap-2 rounded-xl border border-current/15 px-3 py-2 text-xs font-semibold underline-offset-2 hover:underline"><MessageTypeIcon type={message.type} />{attachment}</a>}
        {message.type === "audio" && !message.body && <div className="flex items-center gap-3"><Mic className="h-4 w-4" /><span className="h-1.5 w-24 rounded-full bg-current/30" /><span className="font-mono-app text-[10px]">{message.durationSeconds || 0}s</span></div>}
      </div>
      <span className="mt-1 px-1 font-mono-app text-[9px] text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100">{formatTime(message.createdAt)}{message.isMine && message.readAt ? " · Read" : ""}</span>
    </div>
  </div>;
}

export function Composer({ onSend, onUpload, onVoiceNote, sending = false }: { onSend: (body: string) => void; onUpload?: (file: File) => void; onVoiceNote?: (file: File, durationSeconds: number) => void; sending?: boolean }) {
  const [value, setValue] = useState("");
  const [recording, setRecording] = useState(false);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const startedAtRef = useRef(0);
  const submit = () => { if (value.trim()) { onSend(value.trim()); setValue(""); } };
  const handleFile = (event: ChangeEvent<HTMLInputElement>) => { const file = event.target.files?.[0]; if (file) onUpload?.(file); event.target.value = ""; };
  const toggleRecording = async () => {
    if (recording && recorderRef.current) { recorderRef.current.stop(); setRecording(false); return; }
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      startedAtRef.current = Date.now();
      recorder.ondataavailable = (event) => { if (event.data.size) chunksRef.current.push(event.data); };
      recorder.onstop = () => {
        stream.getTracks().forEach((track) => track.stop());
        const duration = Math.max(1, Math.round((Date.now() - startedAtRef.current) / 1000));
        onVoiceNote?.(new File(chunksRef.current, `voice-note-${Date.now()}.webm`, { type: "audio/webm" }), duration);
        recorderRef.current = null;
      };
      recorderRef.current = recorder;
      recorder.start();
      setRecording(true);
    } catch { setRecording(false); }
  };
  return <div className="border-t border-border bg-background/85 p-4 backdrop-blur-md md:px-8"><div className="mx-auto flex max-w-4xl items-end gap-2 rounded-2xl border border-border bg-card p-2 shadow-[0_10px_35px_hsl(22_49%_19%_/_0.06)]">
    <label className="grid h-10 w-10 shrink-0 cursor-pointer place-items-center rounded-xl text-muted-foreground transition-colors hover:bg-secondary hover:text-primary" data-testid="button-attach"><Paperclip className="h-[18px] w-[18px]" strokeWidth={1.8} /><input type="file" accept="image/*,video/*" onChange={handleFile} className="hidden" /></label>
    <textarea value={value} onChange={(e) => setValue(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); } }} placeholder={recording ? "Recording a voice note…" : "Write something warm…"} rows={1} className="max-h-28 min-h-10 flex-1 resize-none bg-transparent px-2 py-2.5 text-sm outline-none placeholder:text-muted-foreground/70" data-testid="input-message" disabled={recording} />
    <button onClick={toggleRecording} className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl transition-colors ${recording ? "bg-[#d76d59] text-[#fff4e2]" : "text-muted-foreground hover:bg-secondary hover:text-primary"}`} data-testid="button-record" aria-label={recording ? "Stop recording" : "Record voice message"}><Mic className="h-[18px] w-[18px]" strokeWidth={1.8} /></button>
    <button onClick={submit} disabled={sending || !value.trim()} className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-accent text-accent-foreground transition-all hover:-translate-y-0.5 hover:shadow-[0_4px_12px_hsl(37_94%_55%_/_0.25)] disabled:cursor-not-allowed disabled:opacity-40" data-testid="button-send"><Send className="h-[17px] w-[17px]" strokeWidth={2} /></button>
  </div><p className="mx-auto mt-2 max-w-4xl px-1 text-[10px] text-muted-foreground">Press Enter to send · Shift + Enter for a new line</p></div>;
}

export function NotificationList({ notifications, onRead }: { notifications: Notification[]; onRead?: (notification: Notification) => void }) {
  if (!notifications.length) return <EmptyState title="All caught up" body="Nothing waiting in the wings. Your quiet inbox is doing its job." />;
  return <div className="space-y-2">{notifications.map((notification) => <button key={notification.id} onClick={() => onRead?.(notification)} className={`flex w-full items-start gap-3 rounded-2xl border p-4 text-left transition-colors hover:bg-secondary/60 ${notification.read ? "border-border bg-card" : "border-accent/50 bg-accent/10"}`} data-testid={`button-notification-${notification.id}`}><span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-secondary text-primary"><Bell className="h-4 w-4" strokeWidth={1.8} /></span><span className="min-w-0 flex-1"><span className="flex justify-between gap-3"><span className="text-sm font-semibold">{notification.title}</span><span className="shrink-0 font-mono-app text-[10px] text-muted-foreground">{formatRelative(notification.createdAt)}</span></span><span className="mt-1 block text-xs leading-5 text-muted-foreground">{notification.body}</span></span>{!notification.read && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-[#d76d59]" />}</button>)}</div>;
}

export function SectionLabel({ children }: { children: ReactNode }) { return <p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-muted-foreground">{children}</p>; }