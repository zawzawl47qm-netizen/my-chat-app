import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Menu } from "lucide-react";
import { useLocation, useParams } from "wouter";
import { getListConversationsQueryKey, getListMessagesQueryKey, useGetCurrentUser, useListConversations, useListMessages, useSendMessage, useUpdatePresence } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Avatar, Composer, MessageBubble, PresenceLabel, SectionLabel, SideNav, Topbar } from "@/components/chat-ui";
import { uploadChatAttachment } from "@/lib/storage";

export default function ConversationPage() {
  const { conversationId = "" } = useParams<{ conversationId: string }>();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [mobileOpen, setMobileOpen] = useState(false);
  const currentUserQuery = useGetCurrentUser();
  const conversationsQuery = useListConversations();
  const messagesQuery = useListMessages(conversationId);
  const sendMessage = useSendMessage();
  const updatePresence = useUpdatePresence();
  const conversation = useMemo(() => conversationsQuery.data?.find((item) => item.id === conversationId), [conversationsQuery.data, conversationId]);
  const participant = conversation?.participant;

  useEffect(() => {
    updatePresence.mutate({ data: { status: "online" } });
    return () => { updatePresence.mutate({ data: { status: "online" } }); };
  }, []);

  const send = (body: string, type: "text" | "image" | "video" | "audio" = "text", attachmentUrl?: string, attachmentName?: string, durationSeconds?: number) => {
    sendMessage.mutate({ conversationId, data: { body, type, attachmentUrl, attachmentName, durationSeconds } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListMessagesQueryKey(conversationId) }); queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() }); } });
  };
  const upload = async (file: File) => {
    try {
      const result = await uploadChatAttachment(file);
      const kind = file.type.startsWith("video") ? "video" : "image";
      send(kind === "image" ? "Shared a photo" : "Shared a video", kind, result.servingUrl, file.name);
    } catch (error) {
      // The composer stays usable when storage has not been provisioned yet.
      console.error(error);
    }
  };
  const uploadVoice = async (file: File, durationSeconds: number) => {
    try {
      const result = await uploadChatAttachment(file);
      send("Voice note", "audio", result.servingUrl, file.name, durationSeconds);
    } catch (error) {
      console.error(error);
    }
  };

  return <div className="flex min-h-[100dvh] bg-background"><div className={`fixed inset-0 z-40 bg-primary/20 backdrop-blur-sm transition-opacity md:hidden ${mobileOpen ? "opacity-100" : "pointer-events-none opacity-0"}`} onClick={() => setMobileOpen(false)} /><div className={`fixed inset-y-0 left-0 z-50 transition-transform md:static md:block ${mobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}`}><SideNav currentUser={currentUserQuery.data} active="inbox" onClose={() => setMobileOpen(false)} /></div><main className="flex min-w-0 flex-1 flex-col"><Topbar title="" onBell={() => setLocation("/chat?notifications=1")} onSettings={() => setLocation("/settings")} mobileMenu={<button onClick={() => setMobileOpen(true)} className="grid h-9 w-9 place-items-center rounded-xl bg-secondary md:hidden" data-testid="button-open-menu"><Menu className="h-4 w-4" /></button>} />
    <div className="flex min-h-0 flex-1 flex-col"><header className="flex items-center justify-between border-b border-border/70 bg-background/80 px-5 py-4 backdrop-blur md:px-8"><div className="flex min-w-0 items-center gap-3"><button onClick={() => setLocation("/chat")} className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-muted-foreground hover:bg-secondary hover:text-primary" data-testid="button-back-inbox"><ArrowLeft className="h-4 w-4" /></button>{participant ? <><Avatar user={participant} online={participant.status === "online"} /><div className="min-w-0"><h1 className="truncate font-display text-lg font-bold tracking-[-.03em] text-primary">{participant.name}</h1><PresenceLabel user={participant} /></div></> : <div className="space-y-2"><div className="h-4 w-32 animate-pulse rounded bg-secondary" /><div className="h-2 w-20 animate-pulse rounded bg-secondary" /></div>}</div><div className="font-mono-app text-[10px] uppercase tracking-[.14em] text-muted-foreground">one on one</div></header>
      <div className="scrollbar-warm min-h-0 flex-1 overflow-y-auto px-5 py-8 md:px-8"><div className="mx-auto max-w-4xl"><div className="mb-8 text-center"><SectionLabel>Conversation started here</SectionLabel><p className="mt-2 text-xs text-muted-foreground">Messages are yours to revisit, whenever you need them.</p></div>{messagesQuery.isLoading ? <MessageSkeleton /> : messagesQuery.isError ? <div className="rounded-2xl border border-[#d76d59]/30 bg-[#d76d59]/8 p-5"><p className="text-sm font-semibold text-[#a4493d]">Couldn’t open this thread.</p><button onClick={() => messagesQuery.refetch()} className="mt-3 rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground" data-testid="button-retry-messages">Try again</button></div> : messagesQuery.data?.length ? <div className="space-y-4">{messagesQuery.data.map((message) => <MessageBubble key={message.id} message={message} />)}</div> : <div className="flex min-h-[260px] flex-col items-center justify-center text-center"><div className="mb-4 h-px w-20 bg-border" /><p className="font-display text-2xl font-bold text-primary">A fresh page.</p><p className="mt-2 text-sm text-muted-foreground">Say hello to {participant?.name || "your friend"}.</p></div>}</div></div><Composer sending={sendMessage.isPending} onSend={(body) => send(body)} onUpload={upload} onVoiceNote={uploadVoice} /></div>
  </main></div>;
}

function MessageSkeleton() { return <div className="space-y-5">{[1, 2, 3, 4].map((item) => <div key={item} className={`flex ${item % 2 ? "justify-start" : "justify-end"}`}><div className="h-12 w-48 animate-pulse rounded-[20px] bg-card" /></div>)}</div>; }