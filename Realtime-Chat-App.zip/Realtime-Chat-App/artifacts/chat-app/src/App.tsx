import { useEffect, useRef, type ReactNode } from "react";
import { ClerkProvider, Show, useAuth, useClerk } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Redirect, Route, Router as WouterRouter, Switch, useLocation } from "wouter";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Landing from "@/pages/landing";
import { AuthPage } from "@/pages/auth";
import ChatInbox from "@/pages/chat";
import ConversationPage from "@/pages/conversation";
import SettingsPage from "@/pages/settings";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || "/" : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "#56301e",
    colorForeground: "#38271e",
    colorMutedForeground: "#796d62",
    colorDanger: "#b65043",
    colorBackground: "#f6ead6",
    colorInput: "#fffaf0",
    colorInputForeground: "#38271e",
    colorNeutral: "#d9c9b2",
    fontFamily: "Manrope, sans-serif",
    borderRadius: "0.9rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-[#f6ead6] rounded-[24px] w-[440px] max-w-full overflow-hidden",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "font-display !text-[#56301e] !font-bold",
    headerSubtitle: "!text-[#796d62]",
    socialButtonsBlockButtonText: "!text-[#38271e] !font-semibold",
    formFieldLabel: "!text-[#56301e] !font-semibold",
    footerActionLink: "!text-[#a85a43] !font-bold",
    footerActionText: "!text-[#796d62]",
    dividerText: "!text-[#796d62]",
    identityPreviewEditButton: "!text-[#a85a43]",
    formFieldSuccessText: "!text-[#4d8756]",
    alertText: "!text-[#b65043]",
    logoBox: "mb-3",
    logoImage: "rounded-xl",
    socialButtonsBlockButton: "!border-[#d9c9b2] !bg-[#fffaf0] hover:!bg-[#f0dfc4]",
    formButtonPrimary: "!bg-[#56301e] hover:!bg-[#713e26] !text-[#fff4e2] !font-bold",
    formFieldInput: "!border-[#d9c9b2] !bg-[#fffaf0] !text-[#38271e] focus:!border-[#a85a43] focus:!ring-[#f4bd72]",
    footerAction: "border-0",
    dividerLine: "!bg-[#d9c9b2]",
    alert: "!bg-[#f8dcd2] !border-[#d76d59]/30",
    otpCodeFieldInput: "!border-[#d9c9b2] !bg-[#fffaf0]",
    formFieldRow: "gap-2",
    main: "gap-4",
  },
};

function HomeRedirect() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <div className="grid min-h-[100dvh] place-items-center bg-background"><div className="animate-pulse-soft font-mono-app text-xs text-muted-foreground">Making room…</div></div>;
  return isSignedIn ? <Redirect to="/chat" /> : <Landing />;
}

function Protected({ children }: { children: ReactNode }) {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <div className="grid min-h-[100dvh] place-items-center bg-background"><div className="animate-pulse-soft font-mono-app text-xs text-muted-foreground">Making room…</div></div>;
  return isSignedIn ? <>{children}</> : <Redirect to="/" />;
}

function SignInRoute() { return <AuthPage mode="sign-in" />; }
function SignUpRoute() { return <AuthPage mode="sign-up" />; }

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const previousUser = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const nextUser = user?.id ?? null;
      if (previousUser.current !== undefined && previousUser.current !== nextUser) client.clear();
      previousUser.current = nextUser;
    });
    return unsubscribe;
  }, [addListener, client]);
  return null;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={HomeRedirect} />
    <Route path="/sign-in/*?" component={SignInRoute} />
    <Route path="/sign-up/*?" component={SignUpRoute} />
    <Route path="/chat"><Protected><ChatInbox /></Protected></Route>
    <Route path="/chat/:conversationId"><Protected><ConversationPage /></Protected></Route>
    <Route path="/settings"><Protected><SettingsPage /></Protected></Route>
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}

function ClerkRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} localization={{ signIn: { start: { title: "Welcome back", subtitle: "Your people are one sign-in away." } }, signUp: { start: { title: "Make some room", subtitle: "A warmer inbox starts here." } } }} routerPush={(to) => setLocation(stripBase(to))} routerReplace={(to) => setLocation(stripBase(to), { replace: true })}><ClerkQueryClientCacheInvalidator /><Router /></ClerkProvider>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={basePath}><ClerkRoutes /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;