export async function uploadChatAttachment(file: File): Promise<{ objectPath: string; servingUrl: string }> {
  const request = await fetch("/api/storage/uploads/request-url", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
  });
  if (!request.ok) throw new Error("Attachment upload is unavailable right now.");
  const { uploadURL, objectPath } = await request.json() as { uploadURL: string; objectPath: string };
  const uploaded = await fetch(uploadURL, { method: "PUT", headers: { "Content-Type": file.type }, body: file });
  if (!uploaded.ok) throw new Error("The attachment could not be uploaded.");
  return { objectPath, servingUrl: `/api/storage${objectPath}` };
}