import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { getAuth } from "@clerk/express";
import { and, asc, desc, eq, ilike, or } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  chatUsersTable,
  conversationMembersTable,
  conversationsTable,
  messagesTable,
  notificationsTable,
} from "@workspace/db";
import {
  CreateConversationBody,
  ListUsersQueryParams,
  SendMessageBody,
  UpdatePresenceBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

type AuthedRequest = Request & { userId?: string };

function userIdFor(req: Request): string {
  const auth = getAuth(req);
  return auth?.userId || (process.env.NODE_ENV === "production" ? "" : "demo-user");
}

function requireUser(req: Request, res: Response, next: NextFunction) {
  const userId = userIdFor(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  (req as AuthedRequest).userId = userId;
  next();
}

function initials(name: string) {
  return name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

async function ensureUser(userId: string) {
  const existing = await db
    .select()
    .from(chatUsersTable)
    .where(eq(chatUsersTable.id, userId))
    .limit(1);
  if (existing[0]) return existing[0];

  const name = userId === "demo-user" ? "Alex Morgan" : "New member";
  const created = await db
    .insert(chatUsersTable)
    .values({
      id: userId,
      name,
      username: userId === "demo-user" ? "alexmorgan" : `member-${userId.slice(-8)}`,
      initials: initials(name),
      status: "online",
      bio: "Ready to connect",
    })
    .onConflictDoNothing()
    .returning();
  return created[0] || (await db.select().from(chatUsersTable).where(eq(chatUsersTable.id, userId)).limit(1))[0];
}

async function ensureDemoUsers() {
  const demos = [
    { id: "demo-sam", name: "Sam Rivera", username: "samrivera", initials: "SR", status: "online", bio: "Product designer" },
    { id: "demo-jordan", name: "Jordan Lee", username: "jordanlee", initials: "JL", status: "away", bio: "Building something new" },
    { id: "demo-maya", name: "Maya Patel", username: "mayapatel", initials: "MP", status: "offline", bio: "Coffee, cameras, code" },
    { id: "demo-noah", name: "Noah Williams", username: "noahwilliams", initials: "NW", status: "online", bio: "Always up for a chat" },
  ];
  for (const demo of demos) {
    await db.insert(chatUsersTable).values(demo).onConflictDoNothing();
  }
}

function mapUser(user: typeof chatUsersTable.$inferSelect) {
  return {
    id: user.id,
    name: user.name,
    username: user.username,
    initials: user.initials,
    avatarUrl: user.avatarUrl,
    status: user.status,
    lastSeen: user.lastSeen.toISOString(),
    bio: user.bio,
  };
}

router.get("/me", requireUser, async (req, res) => {
  const user = await ensureUser((req as AuthedRequest).userId!);
  res.json(mapUser(user));
});

router.get("/users", requireUser, async (req, res) => {
  await ensureUser((req as AuthedRequest).userId!);
  await ensureDemoUsers();
  const parsed = ListUsersQueryParams.parse(req.query);
  const conditions = [];
  if (parsed.search) {
    conditions.push(or(ilike(chatUsersTable.name, `%${parsed.search}%`), ilike(chatUsersTable.username, `%${parsed.search}%`)));
  }
  if (parsed.status === "online") conditions.push(eq(chatUsersTable.status, "online"));
  conditions.push(eq(chatUsersTable.id, (req as AuthedRequest).userId!) ? undefined : undefined);
  const users = await db
    .select()
    .from(chatUsersTable)
    .where(and(...conditions.filter(Boolean)))
    .orderBy(asc(chatUsersTable.name));
  res.json(users.filter((user) => user.id !== (req as AuthedRequest).userId).map(mapUser));
});

router.get("/conversations", requireUser, async (req, res) => {
  const userId = (req as AuthedRequest).userId!;
  await ensureUser(userId);
  await ensureDemoUsers();
  const memberships = await db.select().from(conversationMembersTable).where(eq(conversationMembersTable.userId, userId));
  const results = [];
  for (const membership of memberships) {
    const others = await db
      .select({ user: chatUsersTable, member: conversationMembersTable })
      .from(conversationMembersTable)
      .innerJoin(chatUsersTable, eq(chatUsersTable.id, conversationMembersTable.userId))
      .where(and(eq(conversationMembersTable.conversationId, membership.conversationId), eq(conversationMembersTable.userId, membership.conversationId ? conversationMembersTable.userId : "")));
    const participant = others.find((entry) => entry.user.id !== userId)?.user;
    if (!participant) continue;
    const last = await db.select().from(messagesTable).where(eq(messagesTable.conversationId, membership.conversationId)).orderBy(desc(messagesTable.createdAt)).limit(1);
    results.push({
      id: membership.conversationId,
      participant: mapUser(participant),
      unreadCount: membership.unreadCount,
      lastMessage: last[0]?.body ?? (last[0]?.type === "image" ? "Photo" : last[0]?.type === "video" ? "Video" : last[0]?.type === "audio" ? "Voice message" : null),
      lastMessageType: last[0]?.type ?? null,
      updatedAt: last[0]?.createdAt?.toISOString() ?? new Date().toISOString(),
    });
  }
  res.json(results);
});

router.post("/conversations", requireUser, async (req, res) => {
  const userId = (req as AuthedRequest).userId!;
  const { participantId } = CreateConversationBody.parse(req.body);
  await ensureUser(userId);
  await ensureDemoUsers();
  const candidate = await db.select().from(chatUsersTable).where(eq(chatUsersTable.id, participantId)).limit(1);
  if (!candidate[0]) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  const existing = await db.select().from(conversationMembersTable).where(eq(conversationMembersTable.userId, userId));
  for (const membership of existing) {
    const hasParticipant = await db.select().from(conversationMembersTable).where(and(eq(conversationMembersTable.conversationId, membership.conversationId), eq(conversationMembersTable.userId, participantId))).limit(1);
    if (hasParticipant[0]) {
      res.json({ id: membership.conversationId, participant: mapUser(candidate[0]), unreadCount: membership.unreadCount, lastMessage: null, lastMessageType: null, updatedAt: new Date().toISOString() });
      return;
    }
  }
  const conversation = await db.insert(conversationsTable).values({}).returning();
  const id = conversation[0].id;
  await db.insert(conversationMembersTable).values([{ conversationId: id, userId }, { conversationId: id, userId: participantId }]);
  res.status(201).json({ id, participant: mapUser(candidate[0]), unreadCount: 0, lastMessage: null, lastMessageType: null, updatedAt: conversation[0].updatedAt.toISOString() });
});

router.get("/conversations/:conversationId/messages", requireUser, async (req, res) => {
  const userId = (req as AuthedRequest).userId!;
  const membership = await db.select().from(conversationMembersTable).where(and(eq(conversationMembersTable.conversationId, req.params.conversationId), eq(conversationMembersTable.userId, userId))).limit(1);
  if (!membership[0]) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  await db.update(conversationMembersTable).set({ unreadCount: 0 }).where(and(eq(conversationMembersTable.conversationId, req.params.conversationId), eq(conversationMembersTable.userId, userId)));
  const rows = await db.select({ message: messagesTable, sender: chatUsersTable }).from(messagesTable).innerJoin(chatUsersTable, eq(chatUsersTable.id, messagesTable.senderId)).where(eq(messagesTable.conversationId, req.params.conversationId)).orderBy(asc(messagesTable.createdAt));
  res.json(rows.map(({ message, sender }) => ({
    id: message.id,
    conversationId: message.conversationId,
    senderId: message.senderId,
    senderName: sender.name,
    body: message.body,
    type: message.type,
    attachmentUrl: message.attachmentUrl,
    attachmentName: message.attachmentName,
    durationSeconds: message.durationSeconds,
    createdAt: message.createdAt.toISOString(),
    isMine: message.senderId === userId,
    readAt: message.readAt?.toISOString() ?? null,
  })));
});

router.post("/conversations/:conversationId/messages", requireUser, async (req, res) => {
  const userId = (req as AuthedRequest).userId!;
  const body = SendMessageBody.parse(req.body);
  const membership = await db.select().from(conversationMembersTable).where(and(eq(conversationMembersTable.conversationId, req.params.conversationId), eq(conversationMembersTable.userId, userId))).limit(1);
  if (!membership[0]) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }
  const sender = await ensureUser(userId);
  const created = await db.insert(messagesTable).values({
    conversationId: req.params.conversationId,
    senderId: userId,
    body: body.body ?? null,
    type: body.type,
    attachmentUrl: body.attachmentUrl ?? null,
    attachmentName: body.attachmentName ?? null,
    durationSeconds: body.durationSeconds ?? null,
  }).returning();
  await db.update(conversationsTable).set({ updatedAt: created[0].createdAt }).where(eq(conversationsTable.id, req.params.conversationId));
  const participants = await db.select().from(conversationMembersTable).where(eq(conversationMembersTable.conversationId, req.params.conversationId));
  for (const participant of participants) {
    if (participant.userId !== userId) {
      await db.update(conversationMembersTable).set({ unreadCount: participant.unreadCount + 1 }).where(and(eq(conversationMembersTable.conversationId, req.params.conversationId), eq(conversationMembersTable.userId, participant.userId)));
      await db.insert(notificationsTable).values({ userId: participant.userId, kind: "message", title: sender.name, body: body.body || `Sent a ${body.type}`, conversationId: req.params.conversationId });
    }
  }
  const message = created[0];
  res.status(201).json({ id: message.id, conversationId: message.conversationId, senderId: message.senderId, senderName: sender.name, body: message.body, type: message.type, attachmentUrl: message.attachmentUrl, attachmentName: message.attachmentName, durationSeconds: message.durationSeconds, createdAt: message.createdAt.toISOString(), isMine: true, readAt: null });
});

router.post("/presence", requireUser, async (req, res) => {
  const userId = (req as AuthedRequest).userId!;
  const { status } = UpdatePresenceBody.parse(req.body);
  const user = await ensureUser(userId);
  const updated = await db.update(chatUsersTable).set({ status, lastSeen: new Date() }).where(eq(chatUsersTable.id, userId)).returning();
  res.json(mapUser(updated[0] ?? user));
});

router.get("/notifications", requireUser, async (req, res) => {
  const rows = await db.select().from(notificationsTable).where(and(eq(notificationsTable.userId, (req as AuthedRequest).userId!), eq(notificationsTable.read, false))).orderBy(desc(notificationsTable.createdAt)).limit(30);
  res.json(rows.map((notification) => ({ ...notification, createdAt: notification.createdAt.toISOString() })));
});

router.post("/notifications/read", requireUser, async (req, res) => {
  await db.update(notificationsTable).set({ read: true }).where(eq(notificationsTable.userId, (req as AuthedRequest).userId!));
  res.status(204).end();
});

export default router;